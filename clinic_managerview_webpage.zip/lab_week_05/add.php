<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Document</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet">
  <?php 
    require_once("./conn.php");
    if($_SERVER["REQUEST_METHOD"] == "POST"){
      $query = "INSERT INTO `student`(`first_name`, `surname`, `home_address`, `parent_phone`, `parent_email`, `date_of_birth`, `subscribed`) VALUES (:first_name, :surname, :home_address, :parent_phone, :parent_email, :date_of_birth, :subscribed)";
      $stmt = $dbh->prepare($query);
      $subscribed = 0;
      if($_POST["subscribed"] == "on"){
        $subscribed = 1;
      }
      $stmt->execute([
        "first_name" => $_POST["first_name"],
        "surname" => $_POST["surname"],
        "home_address" => (empty($_POST["home_address"])) ? null : $_POST["home_address"],
        "parent_phone" => $_POST["parent_phone"],
        "parent_email" => $_POST["parent_email"],
        "date_of_birth" => (empty($_POST["date_of_birth"])) ? null : $_POST["date_of_birth"],
        "subscribed" => $subscribed,
      ]);
      header('Location: ./index.php');
    }
  ?>

</head>
<body>
  <nav class="navbar navbar-expand-lg bg-body-tertiary">
    <div class="container">
      <span class="navbar-brand mb-0 h1">Sutdent Table</span>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarNavDropdown">
        <ul class="navbar-nav ms-auto">
          <li class="nav-item">
            <a class="nav-link" aria-current="page" href="./index.php">List students</a>
          </li>
          <li class="nav-item">
            <a class="nav-link active" href="./add.php">Add new student</a>
          </li>
        </ul>
      </div>
    </div>
  </nav>
  <div class="container">
    <div class="mx-auto my-1">
      <h1>Add new student</h1>
      <p class="lead">please fill in the student information below:</p>
    </div>

    <form action="./add.php" method="post" class="row g-3">
      <div  class="col-md-4">
        <label class="form-label" for="first_name">First Name</label>
        <input class="form-control" type="text" name="first_name" id="first_name" required>
      </div>
      <div  class="col-md-4">
        <label class="form-label" for="surname">Surname</label>
        <input class="form-control" type="text" name="surname" id="surname" required>
      </div>
      <div  class="col-md-4">
        <label class="form-label" for="date_of_birth">Date Of Birth</label>
        <input class="form-control" type="date" name="date_of_birth" id="date_of_birth">
      </div>
      <div  class="col-md-12">
        <label class="form-label" for="home_address">Home Address</label>
        <input class="form-control" type="text" name="home_address" id="home_address">
      </div>
      <div  class="col-md-4">
        <label class="form-label" for="parent_phone">Parent Phone/Mobile</label>
        <input class="form-control" type="text" name="parent_phone" id="parent_phone">
      </div>
      <div  class="col-md-8">
        <label class="form-label" for="parent_email">Parent Email</label>
        <input class="form-control" type="text" name="parent_email" id="parent_email" required>
      </div>
     
      <div class="form-check form-switch">
        <input class="form-check-input" name="subscribed" id="subscribed" type="checkbox" value="1" checked>
        <label class="form-check-label" for="subscribed">subscribed to newsletter</label>
      </div>
      <div>
        <input type="submit" class="btn btn-primary" value="Submit">
      </div>
    </form>

  </div>
  
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.bundle.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/jquery@3.7.0/dist/jquery.min.js" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
</body>
</html>