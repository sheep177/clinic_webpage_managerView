<?php 
  $servername = "localhost";
  $username = "fit2104";
  $password = "fit2104";
  $dbname = "fit2104_23s2_lab05";

  $d_server = "mysql:host=$servername;dbname=$dbname";
  $dbh = new PDO($d_server, "$username", "$password");
?>