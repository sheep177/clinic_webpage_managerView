<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Document</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
  <?php
    require_once("./conn.php");
    include_once("./utils.php");
    $stat = $dbh->prepare("SELECT * FROM `student`");
    $stat->execute();

  ?>
  <nav class="navbar navbar-expand-lg bg-body-tertiary">
    <div class="container">
      <span class="navbar-brand mb-0 h1">Sutdent Table</span>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarNavDropdown">
        <ul class="navbar-nav ms-auto">
          <li class="nav-item">
            <a class="nav-link active" aria-current="page" href="./index.php">List students</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="./add.php">Add new student</a>
          </li>
        </ul>
      </div>
    </div>
  </nav>



  <div class="container">
    <div class="student-table py-3">
      <table class="table">
        <thead>
          <th scope="col">ID</th>
          <th scope="col">First Name</th>
          <th scope="col">Surname</th>
          <th scope="col">Home Address</th>
          <th scope="col">Parent Phone/Mobile</th>
          <th scope="col">Parent Email</th>
          <th scope="col">Date of Birth</th>
          <th scope="col">Subscribed?</th>
          <th scope="col">Actions</th>
        </thead>
        <tbody>
          <?php while ($row = $stat->fetchObject()):  ?>
            <tr>
              <td><?php echo $row->id ?></td>
              <td class="first_name"><?php echo $row->first_name ?></td>
              <td class="surname"><?php echo $row->surname ?></td>
              <td><?php echo $row->home_address ?></td>
              <td><a href="tel:<?= formatPhoneFn($row->parent_phone) ?>"><?php echo formatPhoneFn($row->parent_phone) ?></a> </td>
              <td><a href="mailto:<?= formatPhoneFn($row->parent_email) ?>"> <?php echo $row->parent_email ?> </a> </td>
              <td><?php echo (new DateTime("$row->date_of_birth"))->format("j M o") ?></td> 
              <td><?php echo $row->subscribed ? "✅" : "❌" ?></td>
              <td><a href="./delete.php?id=<?= $row->id ?>" type="button" class="btn delete-sutdent btn-danger">Delete</a></td>
            </tr>
          <?php endwhile?>
        

        </tbody>
      </table>
    </div>
  </div>
</body>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/jquery@3.7.0/dist/jquery.min.js" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<script>
  $(function(){
    $(".delete-sutdent").on("click", function(e){
      var first_name = $(this).parents("tr").find(".first_name").text();
      var surname = $(this).parents("tr").find(".surname").text();
       var result = confirm(`Are you sure to delete the student "${first_name} ${surname}"`)
       if(!result){
        e.preventDefault();
       }
    })
  })

</script>
</html>