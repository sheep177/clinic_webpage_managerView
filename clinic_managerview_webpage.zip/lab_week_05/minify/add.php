<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Document</title>
  <style>
    div{
      line-height:36px;
    }

  </style>
  <?php 
    require_once("../conn.php");
    if($_SERVER["REQUEST_METHOD"] == "POST"){
      $query = "INSERT INTO `student`(`first_name`, `surname`, `home_address`, `parent_phone`, `parent_email`, `date_of_birth`, `subscribed`) VALUES (:first_name, :surname, :home_address, :parent_phone, :parent_email, :date_of_birth, :subscribed)";
      $stmt = $dbh->prepare($query);
      $subscribed = 0;
      if($_POST["subscribed"] == "on"){
        $subscribed = 1;
      }
      $stmt->execute([
        "first_name" => $_POST["first_name"],
        "surname" => $_POST["surname"],
        "home_address" => $_POST["home_address"],
        "parent_phone" => $_POST["parent_phone"],
        "parent_email" => $_POST["parent_email"],
        "date_of_birth" => $_POST["date_of_birth"],
        "subscribed" => $subscribed,
      ]);
      header('Location: ./index.php');
    }
  ?>

</head>
<body>
  <h1>Add New Student</h1>
  <form action="./add.php" method="post">
    <div>
      <label for="first_name">First Name</label>
      <input type="text" name="first_name" id="first_name">
    </div>
    <div>
      <label for="surname">Surname</label>
      <input type="text" name="surname" id="surname">
    </div>
    <div>
      <label for="home_address">Home Address</label>
      <input type="text" name="home_address" id="home_address">
    </div>
    <div>
      <label for="parent_phone">Parent Phone/Mobile</label>
      <input type="text" name="parent_phone" id="parent_phone">
    </div>
    <div>
      <label for="parent_email">Parent Email</label>
      <input type="text" name="parent_email" id="parent_email">
    </div>
    <div>
      <label for="date_of_birth">Date Of Birth</label>
      <input type="date" name="date_of_birth" id="date_of_birth">
    </div>
    <div>
      <input type="checkbox" name="subscribed" id="subscribed">
      <label for="subscribed">subscribed to newsletter</label>
    </div>
    <div>
      <input type="submit" value="add">
    </div>
  </form>
</body>
</html>