<?php
  require_once("../conn.php");
  // 获取一个 id
  if(!empty($_GET["id"])){
    $query = "DELETE FROM `student` WHERE `id` = :id";
    $stmt = $dbh->prepare($query);

    $stmt->execute([
      "id" => $_GET["id"]
    ]);
    
    header("Location: ./index.php");
  }
?>