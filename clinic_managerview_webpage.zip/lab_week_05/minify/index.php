<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Document</title>
</head>
<body>
  <?php
    require_once("../conn.php");
    $stat = $dbh->prepare("SELECT * FROM `student`");
    $stat->execute();

  ?>

  <div class="container">
    <p><a href="./add.php">add new student</a></p>
    <div class="student-table py-3">
      <table class="table" border="1">
        <thead>
          <th>ID</th>
          <th>First Name</th>
          <th>Surname</th>
          <th>Home Address</th>
          <th>Parent Phone/Mobile</th>
          <th>Parent Email</th>
          <th>Date of Birth</th>
          <th>Subscribed?</th>
          <th>Actions</th>
        </thead>
        <tbody>
          <?php while ($row = $stat->fetchObject()):  ?>
            <tr >
              <td><?php echo $row->id ?></td>
              <td><?php echo $row->first_name ?></td>
              <td><?php echo $row->surname ?></td>
              <td><?php echo $row->home_address ?></td>
              <td><?php echo $row->parent_phone ?> </td>
              <td><?php echo $row->parent_email ?></td>
              <td><?php echo $row->date_of_birth ?></td> 
              <td><?php echo $row->subscribed ?></td>
              <td><a href="./delete.php?id=<?= $row->id ?>">Delete</a></td>
            </tr>
          <?php endwhile?>
        

        </tbody>
      </table>
    </div>
  </div>
</body>
</html>